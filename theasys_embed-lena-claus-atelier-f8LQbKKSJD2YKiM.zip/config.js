/*
* Theasys
* Generated on: Tuesday 6th of December 2022 01:26:02 PM
* Config file: You can change the path to match your server path.
*/

var vars = {
    file : 'index.html',
    path : 'http://localhost',//path to the index.html
    theme : 'theasys',
};